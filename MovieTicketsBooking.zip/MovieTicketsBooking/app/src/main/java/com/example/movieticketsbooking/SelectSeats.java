package com.example.movieticketsbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.movieticketsbooking.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class SelectSeats extends AppCompatActivity {

    boolean status;
    private String[] id = new String[40];
    private ToggleButton[] seats = new ToggleButton[40];
    public ArrayList<String> seatsSelected = new ArrayList<>();
    private ToggleButton coupleSeat1;
    private ToggleButton coupleSeat2;
    String message = "Seats selected: ";
    public String movieTitle;
    public String date;
    public String time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_seats);

        int temp;
        for (int i = 0; i < 10; i++) {
            if (i < 9)
            {
                id[i] = "A0" + (i + 1);
            }
            else {
                id[i] = "A" + ( i + 1);
            }
        }

        for (int i = 0; i < 10; i++) {
            if (i < 9)
            {
                id[i+10] = "B0" + (i + 1);
            }
            else {
                id[i+10] = "B" + (i + 1);
            }
        }

        for (int i = 0; i < 10; i++) {
            if (i < 9)
            {
                id[i+20] = "C0" + (i + 1);
            }
            else {
                id[i+20] = "C" + (i + 1);
            }
        }

        for (int i = 0; i < 10; i++) {
            if (i < 9)
            {
                id[i+30] = "D0" + (i + 1);
            }
            else {
                id[i+30] = "D" + (i + 1);
            }
        }

        for (int i = 0; i< id.length; i++){
            temp = getResources().getIdentifier(id[i], "id", getPackageName());
            seats[i] = findViewById(temp);
        }
    }

    public void onCoupleSeatClicked(View view) {
        // select couple seats side by side
        switch (view.getId()) {
            case R.id.A03:
                coupleSeat1 = findViewById(R.id.A03);
                coupleSeat2 = findViewById(R.id.A04);
                break;
            case R.id.A04:
                coupleSeat1 = findViewById(R.id.A04);
                coupleSeat2 = findViewById(R.id.A03);
                break;
            case R.id.A05:
                coupleSeat1 = findViewById(R.id.A05);
                coupleSeat2 = findViewById(R.id.A06);
                break;
            case R.id.A06:
                coupleSeat1 = findViewById(R.id.A06);
                coupleSeat2 = findViewById(R.id.A05);
                break;
            case R.id.A07:
                coupleSeat1 = findViewById(R.id.A07);
                coupleSeat2 = findViewById(R.id.A08);
                break;
            case R.id.A08:
                coupleSeat1 = findViewById(R.id.A08);
                coupleSeat2 = findViewById(R.id.A07);
                break;
            default:
                // do nothing
                break;
        }

        if (coupleSeat1.isChecked())
            coupleSeat2.setChecked(true);
        else
            coupleSeat2.setChecked(false);
    }

    public void onConfirmButtonClicked(View view) {
        // get selected seats
        seatsSelected.clear();
        for (int i = 0; i < 40; i++) {
            status = seats[i].isChecked();
            if (status) {
                seatsSelected.add(id[i]);
            }
        }
        int size = seatsSelected.size();
        for (int i = 0; i < size; i ++) {
            Log.d ("Seats Selected: ", seatsSelected.get(i));
            message += seatsSelected.get(i) + " ";
        }
        displayToast(message);

        final Intent intent = new Intent(this, ConfirmTicket.class);
        Intent getIntent = getIntent();
        Bundle extras = new Bundle();
        date = getIntent.getStringExtra("Date");
        time = getIntent.getStringExtra("Time");
        movieTitle = getIntent.getStringExtra("Title");
        extras.putString("Title", movieTitle);
        extras.putString("Date", date);
        extras.putString("Time", time);
        extras.putStringArrayList("Seats", seatsSelected);
        intent.putExtras(extras);

        Thread thread = new Thread(){
            @Override
            public void run() {
                try {
                    Thread.sleep(1500);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        thread.start();
    }

    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }
}
