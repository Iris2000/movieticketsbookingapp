package com.example.movieticketsbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import java.text.SimpleDateFormat;

public class Payment extends AppCompatActivity {

    EditText card_num, phone_num, cvv, date, name;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        name = (EditText) findViewById(R.id.editText);
        card_num = (EditText) findViewById(R.id.card_num);
        phone_num = (EditText) findViewById(R.id.phone_num);
        cvv = (EditText) findViewById(R.id.CVVs);
        date = (EditText) findViewById(R.id.e_date);


        btn = (Button) findViewById(R.id.button_pay);

        btn.setOnClickListener(new View.OnClickListener(){
        public void onClick(View view){
            String cardnum = card_num.getText().toString();
            String phone = phone_num.getText().toString();
            String CVV = cvv.getText().toString();
            String dates = date.getText().toString();
            String format = "(0?[1-9]|1[012])/(2?[1-9]|3?[0-9]\\d\\d)";

            if(cardnum.length()!=16){
                card_num.setError("Error");
                card_num.requestFocus();
            }

            else if(phone.length()>11 || phone.length()<10){
                phone_num.setError("Error");
                phone_num.requestFocus();
            }

            else if(CVV.length()!=3){
                cvv.setError("Error");
                cvv.requestFocus();
            }

            else if(!dates.matches(format)){
                date.setError("Error");
                date.requestFocus();
            }
            else {
                Intent activity2Intent = new Intent(getApplicationContext(), MyTicket.class);
                startActivity(activity2Intent);
            }
        }

        });

    }




}
