package com.example.movieticketsbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ConfirmTicket extends AppCompatActivity {

    private int normalSeats = 0;
    private int coupleSeats = 0;
    private int accessibleSeats = 0;
    private String seats = "";
    public ArrayList<String> seatsSelected = new ArrayList<>();
    private String subtotal = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_ticket);

        int normalSeatsP;
        int coupleSeatsP;
        int accessibleSeatsP;
        int totalPrice;

        Intent intent = getIntent();
        seatsSelected = intent.getStringArrayListExtra("Seats");
        int size = seatsSelected.size();
        for (int i = 0; i < size; i++) {
            seats += seatsSelected.get(i) + " ";
        }

        TextView mTitle = findViewById(R.id.titleTextView);
        TextView mDate = findViewById(R.id.dateTextView);
        TextView mTime = findViewById(R.id.timeTextView);
        TextView mSeats = findViewById(R.id.seatsTextView);
        TextView mPrice = findViewById(R.id.priceTextView);
        TextView mSubTotal = findViewById(R.id.subTotal);

        mTitle.setText(intent.getStringExtra("Title"));
        mDate.setText(intent.getStringExtra("Date"));
        mTime.setText(intent.getStringExtra("Time"));
        mSeats.setText(seats);

        for (int i = 0; i < seatsSelected.size(); i ++) {
            if (seatsSelected.get(i).equals("A09") || seatsSelected.get(i).equals("A10")) {
                accessibleSeats++;
            } else if (seatsSelected.get(i).equals("A03") || seatsSelected.get(i).equals("A04") || seatsSelected.get(i).equals("A05") || seatsSelected.get(i).equals("A06") ||
                        seatsSelected.get(i).equals("A07") || seatsSelected.get(i).equals("A08")) {
                coupleSeats++;
            } else {
                normalSeats++;
            }
        }

        normalSeatsP = normalSeats * 17;
        coupleSeatsP = coupleSeats * 24;
        accessibleSeatsP = accessibleSeats * 12;
        totalPrice = normalSeatsP + coupleSeatsP + accessibleSeatsP;

        if (normalSeats != 0) {
            subtotal += "Normal Seats x" + normalSeats + "\t\t\t\t\t\t" + normalSeatsP;
        }
        if (coupleSeats != 0) {
            subtotal += "\nCouple Seats x" + coupleSeats + "\t\t\t\t\t\t" + coupleSeatsP;
        }
        if (accessibleSeats != 0) {
            subtotal += "\nAccessible Seats x" + accessibleSeats + "\t\t\t" + accessibleSeatsP;
        }

        mSubTotal.setText(subtotal);
        mPrice.setText("RM " + totalPrice);
    }

    public void onConfirmButtonClicked(View view) {
        Intent intent = new Intent(this, Payment.class);;
        startActivity(intent);
    }

}
