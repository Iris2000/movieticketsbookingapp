package com.example.movieticketsbooking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.movieticketsbooking.R;
import com.example.movieticketsbooking.ChooseDateTime;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    public TextView movie;
    public String movieTitle;
    public int posterImage;
    public String moviedes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode
                (AppCompatDelegate.MODE_NIGHT_YES);
    }

    public void chooseDateTime(View view) {
        Intent intent = new Intent(MainActivity.this, ChooseDateTime.class);

        switch (view.getId()) {
            case R.id.poster1:
                movie = (TextView)findViewById(R.id.title1);
                posterImage = R.drawable.the_boy;
                break;
            case R.id.poster2:
                movie = (TextView)findViewById(R.id.title2);
                posterImage = R.drawable.underwater;
                break;
            case R.id.poster3:
                movie = (TextView)findViewById(R.id.title3);
                posterImage = R.drawable.fantasy_island;
                break;
            case R.id.poster4:
                movie = (TextView)findViewById(R.id.title4);
                posterImage = R.drawable.parasite;
                break;
            case R.id.poster5:
                movie = (TextView)findViewById(R.id.title5);
                posterImage = R.drawable.rock4;
                break;
            case R.id.poster6:
                movie = (TextView)findViewById(R.id.title6);
                posterImage = R.drawable.sonic;
                break;
            case R.id.poster7:
                movie = (TextView)findViewById(R.id.title7);
                posterImage = R.drawable.the_call_of_the_wild;
                break;
            case R.id.poster8:
                movie = (TextView)findViewById(R.id.title8);
                posterImage = R.drawable.little_women;
                break;
            case R.id.poster9:
                movie = (TextView)findViewById(R.id.title9);
                posterImage = R.drawable.dolittle;
                break;
            default:
                // do nothing
                break;
        }
        movieTitle = movie.getText().toString();
        intent.putExtra("Title", movieTitle);
        intent.putExtra("Poster", posterImage);
        startActivity(intent);
    }
}
