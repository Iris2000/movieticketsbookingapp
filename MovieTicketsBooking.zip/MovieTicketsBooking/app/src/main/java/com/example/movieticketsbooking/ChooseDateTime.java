package com.example.movieticketsbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.movieticketsbooking.R;

import java.io.File;

public class ChooseDateTime extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{

    public String message;
    String date = "20 Fri";
    public String movieTitle;
    public String description;
    public String timeSelected;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_date_time);
        Bundle bundle = getIntent().getExtras();

        //set the text of movie description
        TextView textView = (TextView) findViewById(R.id.des);

        // Get poster image
        image = (ImageView) findViewById(R.id.posterImage);
        image.setImageResource(bundle.getInt("Poster"));

        // Get movie title
        TextView mTitle = (TextView) findViewById(R.id.movieTitle);
        movieTitle = bundle.getString("Title");
        mTitle.setText(movieTitle);

        if(movieTitle.equals("Brahms: The Boy II")){
            textView.setText(R.string.brahms_des);
        }
        else if(movieTitle.equals("Underwater")){
            textView.setText(R.string.underwater_des);
        }
        else if(movieTitle.equals("Fantasy Island")){
            textView.setText(R.string.fantasy_des);
        }
        else if(movieTitle.equals("Parasite")){
            textView.setText(R.string.parasite_des);
        }
        else if(movieTitle.equals("Rock 4: Rockers Never Dai")){
            textView.setText(R.string.rock4_des);
        }
        else if(movieTitle.equals("Sonic: The Hedgehog")){
            textView.setText(R.string.sonic_des);
        }
        else if(movieTitle.equals("The Call of The Wild")){
            textView.setText(R.string.call_des);
        }
        else if(movieTitle.equals("Little Women")){
            textView.setText(R.string.women_des);
        }
        else if(movieTitle == "Do Little"){
            textView.setText(R.string.do_little_des);
        }
        description=textView.getText().toString();

        // Create the spinner
        Spinner spinner = findViewById(R.id.time_spinner);
        if (spinner != null) {
            spinner.setOnItemSelectedListener(this);
        }
        // Create ArrayAdapter using the string array and default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.time_spinner_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        if (spinner != null) {
            spinner.setAdapter(adapter);
        }


    }



    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        Boolean checked = ((RadioButton) view).isChecked();
        // Checked which radio button was clicked.
        switch (view.getId()) {
            case R.id.day1:
                if (checked)
                    message = "Date: " + getString(R.string._20_fri);
                    date = "20 Fri";
                break;
            case R.id.day2:
                if (checked)
                    message = "Date: " + getString(R.string._21_sat);
                    date = "21 Sat";
                break;
            case R.id.day3:
                if (checked)
                    displayToast("Date: " + getString(R.string._22_sun));
                    date = "22 Sun";
                break;
            default:
                // Do nothing
                break;
        }
    }

    // Interface callback for when any spinner item is selected.
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        timeSelected = adapterView.getItemAtPosition(position).toString();
    }

    // Interface callback for when no spinner item is selected.
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Do nothing.
    }

    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    public void onConfirmButtonClicked(View view) {
        final Intent intent = new Intent(this, SelectSeats.class);
        Bundle extras  = new Bundle();
        extras.putString("Title", movieTitle);
        extras.putString("Date", date);
        extras.putString("Time", timeSelected);
        intent.putExtras(extras);

        displayToast("Date: " + date + "\nTime: " + timeSelected);

        Thread thread = new Thread(){
            @Override
            public void run() {
                try {
                    Thread.sleep(1500);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        thread.start();
    }

    public void Share(View view) {
        String share = movieTitle +"\n\n"+"Des: "+description;
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, share);
        sendIntent.setType("text/plain");

        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);

    }
}